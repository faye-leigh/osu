

// Copyright 2024 Neil Kirby, not for distribution

#include "stdbool.h"
#include <stdio.h>

#include "frame.h"
#include "output.h"


struct Frame *s_shim(int count, struct Dataset *data_ptrs[]);

short a4[] = { 8};
short a1[] = { 2, -4, 8, -16 };
short a2[] = { 1024, -1024, 1024, -1024, 1024 };
short a3[] = { 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2};

struct Dataset D_three = {100, 1000, { sizeof(a3)/sizeof(a3[0]) , false, a3}};
struct Dataset D_two = { 1024 *1023, 1024 * 1025, { sizeof(a2)/sizeof(a2[0]) , false, a2}};
struct Dataset D_one = {10, 20, { sizeof(a1)/sizeof(a1[0]) , false, a1}};
struct Dataset D_four = {50, 80, { sizeof(a4)/sizeof(a4[0]) , false, a4}};



void run( struct Dataset *dsa[], int fcount)
{
	printf("\nLab 6 calling s_shim with %d frames\n", fcount);
	struct Frame *fp = s_shim(fcount, dsa);
	if (fp)
	{
	    printf("Lab6: s_shim returned this frame:\n");
	    output_frame(fp);
	}
	else printf("Lab6: s_shim did not find any valid frames\n");
}

int main()
{
	struct Dataset *good[] = { &D_three, &D_two, &D_one, &D_four};
	struct Dataset *badone[] = { NULL, NULL};
	struct Dataset *badtwo[] = { &D_three, &D_one};

	run(good, 4);
	run(badone, 0);
	run(badtwo, 2);


	return 0;
}

