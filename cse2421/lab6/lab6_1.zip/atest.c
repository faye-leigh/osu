

// Copyright 2024 Neil Kirby, not for distribution

#include "stdbool.h"
#include <stdio.h>

#include "frame.h"
#include "output.h"

bool a_shim(struct Frame *fp, int min_e, int max_e);

void run(short array[], int count, int min, int max)
{
	struct Frame f;

	f.pcm = array;
	f.count = count;

	printf("\nRunning analyze with range %d to %d with %d samples\n",
		min, max, count);
	if( a_shim(&f, min, max))
	{
printf("%d In range (%d).  Total energy was %ld\n", f.valid, f.avg_energy, f.total_energy);
	}
	else
	{
printf("%d NOT in range (%d).  Total energy was %ld\n", f.valid, f.avg_energy, f.total_energy);
	}
	output_frame(&f);

}


short a4[] = { 8};

short a1[] = { 2, -4, 8, -16, 2048, -8 * 1024, 16 * 1024, -32 * 1024, 32 * 1024 -1, -32 * 1024 , 32 * 1024 -1 , -32 * 1024, -16 * 1024, 8*1024, -2048, 16, -8, 4, -2, 1, 0, -1, 0, 2, -2, 4, 0, -4, 3, 0, -3, 1, 0, -1};
short a2[] = { 1024, -1024, 1024, -1024, 1024 };
short a3[] = { 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2, 2, -2};

int main()
{
	run(a4, sizeof(a4)/sizeof(a4[0]), 50, 80);
	run(a3, sizeof(a3)/sizeof(a3[0]), 100, 1000);
	run(a2, sizeof(a2)/sizeof(a2[0]), 1024 * 1023, 1024 * 1025);
	run(a1, sizeof(a1)/sizeof(a1[0]), 10, 20);

	return 0;
}
