
// Copyright 2024 Neil Kirby, not for distribution

#include "stdbool.h"
#include <stdio.h>

#include "frame.h"


void output_frame(struct Frame *fp)
{
	printf("This frame has\n");
	printf("    valid = %s\n", fp->valid ? "true" : "false");
	printf("    %d samples\n", fp->count);
	printf("    %ld total energy\n", fp->total_energy);
	printf("    %d avg energy\n", fp->avg_energy);
	printf("    %6s    %12s\n", "PCM", "Energy");
	int limit = fp->count;
	if(limit > FRAME_ARRAY_SIZE) limit = FRAME_ARRAY_SIZE;
	for(int i =0; i<limit; i++) printf("    %6d    %12d\n", fp->pcm[i], fp->energy_array[i]);
	for(int i = limit; i< fp->count; i++) printf("    %6d\n", fp->pcm[i]);

}

