﻿using var game = new sprint0.Sprint0();
game.Run();
