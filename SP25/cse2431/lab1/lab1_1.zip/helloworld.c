#include <stdio.h>

int main() {
    printf("Hello, my name is Faye\nI am taking SP25-CSE2431 about Operating Systems.\n");
    return 0;
}