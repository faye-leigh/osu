/* Copyright 2024 Neil Kirby, not for disclosure without permission */

void output_frame(struct Frame *fp);
