/* Copyright 2024 Neil Kirby, not for disclosure without permission */

int main();
void run(short array[], int count, int min, int max);
