/* Copyright 2024 Neil Kirby, not for disclosure without permission */

int main();
void run( struct Dataset *dsa[], int fcount);
