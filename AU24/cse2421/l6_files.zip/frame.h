

// Copyright 2024 Neil Kirby, not for distribution

#include "stdbool.h"

#define FRAME_ARRAY_SIZE (16)
struct Frame
{
	int count;
	bool valid;
	short *pcm;
	long total_energy;
	int avg_energy;
	int energy_array[FRAME_ARRAY_SIZE];
};

struct Dataset 
{
	int min;
	int max;
	struct Frame f;
};

